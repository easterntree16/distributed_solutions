package com.example.distributeschedule.task;

import org.junit.jupiter.api.Test;

import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

public class TaskTest {

    @Test
    public void test() throws InterruptedException {
        Timer timer = new Timer();

        TimerTask task = new TimerTask() {
            @Override
            public void run() {
                System.out.println("hello world");
            }
        };

//        timer.schedule(task, new Date(), 2000);
        timer.schedule(task, 2000, 2000);
        Thread.sleep(100000);
    }
}
