package com.example.distributeschedule.task;

import org.junit.jupiter.api.Test;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class ScheduleServiceTest {

    ScheduledExecutorService executorService = Executors.newScheduledThreadPool(3);

    @Test
    public void test() throws InterruptedException {
        executorService.scheduleAtFixedRate(() -> {
            System.out.println("hello world");
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
            }
            System.out.println("sleep end");
        }, 2, 2, TimeUnit.SECONDS);

        Thread.sleep(1000000);
    }
}
