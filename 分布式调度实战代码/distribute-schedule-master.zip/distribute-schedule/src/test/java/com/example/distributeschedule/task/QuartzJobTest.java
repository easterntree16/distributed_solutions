package com.example.distributeschedule.task;

import com.example.distributeschedule.job.QuartzJob;
import org.junit.jupiter.api.Test;
import org.quartz.*;
import org.quartz.impl.StdSchedulerFactory;

public class QuartzJobTest {

    @Test
    public void test() throws SchedulerException, InterruptedException {
        JobDetail hello = JobBuilder.newJob(QuartzJob.class).withIdentity("hello").build();

        SimpleTrigger helloTrigger = TriggerBuilder.newTrigger().withIdentity("helloTrigger")
                .startNow()
                .withSchedule(SimpleScheduleBuilder.simpleSchedule()
                        .withIntervalInSeconds(2).repeatForever())
                .build();

        Scheduler scheduler = new StdSchedulerFactory().getScheduler();
        scheduler.scheduleJob(hello, helloTrigger);
        scheduler.start();

        Thread.sleep(100000);
        scheduler.shutdown();
    }
}
