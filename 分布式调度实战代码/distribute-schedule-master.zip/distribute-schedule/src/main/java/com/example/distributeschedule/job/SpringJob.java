package com.example.distributeschedule.job;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class SpringJob {

    @Scheduled(cron = "*/2 * * * * *")
    public void test(){
        System.out.println("spring schedule");
    }
}
