package com.example.distributeid;

import com.example.distributeid.dao.ProductLongDao;
import com.example.distributeid.util.HttpClientUtil;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.redis.core.StringRedisTemplate;

import java.util.HashMap;

@SpringBootTest
public class RedisIdTest {

    @Autowired
    private ProductLongDao productLongDao;

    @Autowired
    private StringRedisTemplate stringRedisTemplate;

    @Test
    public void testLeaf(){
        Long productId = stringRedisTemplate.opsForValue().increment("product");
        System.out.println(productId);
        productLongDao.insertProduct(productId, "麻花");
    }
}
