package com.example.distributeid;

import com.example.distributeid.dao.ProductLongDao;
import com.example.distributeid.util.HttpClientUtil;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.HashMap;

@SpringBootTest
public class LeafTest {
    @Autowired
    private ProductLongDao productLongDao;

    @Test
    public void testLeaf(){
        String productId = HttpClientUtil.get("http://localhost:8080/api/segment/get/product", new HashMap<>(), new HashMap<>(), false);
        System.out.println(productId);
        productLongDao.insertProduct(Long.parseLong(productId), "香蕉");
    }

    @Test
    public void testLeafSnow(){
        String productId = HttpClientUtil.get("http://localhost:8080/api/snowflake/get/product", new HashMap<>(), new HashMap<>(), false);
        System.out.println(productId);
        productLongDao.insertProduct(Long.parseLong(productId), "饼干");
    }
}
