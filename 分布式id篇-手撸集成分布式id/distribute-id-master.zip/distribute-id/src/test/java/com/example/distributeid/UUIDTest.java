package com.example.distributeid;

import com.example.distributeid.dao.ProductDao;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.UUID;

@SpringBootTest
public class UUIDTest {

    @Autowired
    private ProductDao productDao;

    @Test
    public void testUUID(){
        String uuid = UUID.randomUUID().toString();
        System.out.println(uuid);
        productDao.insertProduct(uuid, "香蕉");
    }
}
