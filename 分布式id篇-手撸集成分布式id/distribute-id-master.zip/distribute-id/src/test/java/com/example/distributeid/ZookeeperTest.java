package com.example.distributeid;

import com.example.distributeid.dao.ProductLongDao;
import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.KeeperException;
import org.apache.zookeeper.ZooDefs;
import org.apache.zookeeper.ZooKeeper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.redis.core.StringRedisTemplate;

import java.io.IOException;

@SpringBootTest
public class ZookeeperTest {

    @Autowired
    private ProductLongDao productLongDao;

    private ZooKeeper zooKeeper;

    @Test
    public void testZookeeper() throws IOException, InterruptedException, KeeperException {
        zooKeeper = new ZooKeeper("127.0.0.1:2181", 300000, null);
        String path = "/test-seq/test";
        String result = zooKeeper.create(path, "1".getBytes(), ZooDefs.Ids.OPEN_ACL_UNSAFE, CreateMode.EPHEMERAL_SEQUENTIAL);
        System.out.println(result);

        int index = result.indexOf(path);
        String productId = "";
        if (index >= 0) {
            index = index + path.length();
            productId = result.substring(index);
        }
        System.out.println(Long.valueOf(productId));
        productLongDao.insertProduct(Long.valueOf(productId), "苹果");
    }
}
