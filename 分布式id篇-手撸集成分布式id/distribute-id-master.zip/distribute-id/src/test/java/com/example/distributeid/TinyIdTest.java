package com.example.distributeid;

import com.example.distributeid.dao.ProductDao;
import com.example.distributeid.dao.ProductLongDao;
import com.xiaoju.uemc.tinyid.client.utils.TinyId;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;


@SpringBootTest
public class TinyIdTest {

    @Autowired
    private ProductLongDao productLongDao;

    @Test
    public void testTinyId(){
        Long productId = TinyId.nextId("product");
        System.out.println(productId);
        productLongDao.insertProduct(productId, "香蕉");
    }
}
