--商品--
CREATE TABLE `product`
(
    `id`   varchar(50) NOT NULL,
    `name` varchar(50) NOT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='商品表'

--商品ID = long--
CREATE TABLE `product_long`
(
    `id`   bigint      NOT NULL,
    `name` varchar(50) NOT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci

--数据库号段--
CREATE TABLE `segment_id`
(
    `id`      bigint      NOT NULL AUTO_INCREMENT,
    `max_id`  bigint      NOT NULL,
    `step`    int         NOT NULL,
    `biz`     varchar(20) NOT NULL,
    `version` int         NOT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='号段id生成表'

--数据库自增id--
CREATE TABLE `seq_id`
(
    `id`  bigint NOT NULL AUTO_INCREMENT,
    `biz` varchar(10) DEFAULT NULL COMMENT '业务',
    PRIMARY KEY (`id`),
    UNIQUE KEY `seq_id_biz_uindex` (`biz`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci