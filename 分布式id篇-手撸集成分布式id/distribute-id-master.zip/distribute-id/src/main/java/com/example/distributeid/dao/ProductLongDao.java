package com.example.distributeid.dao;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ProductLongDao {

    @Insert("insert into product_long (id, name) values (#{id}, #{name})")
    void insertProduct(Long id, String name);
}
