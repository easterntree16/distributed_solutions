package com.example.distributeid.dao;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ProductDao {

    @Insert("insert into product (id, name) values (#{id}, #{name})")
    void insertProduct(String id, String name);
}
