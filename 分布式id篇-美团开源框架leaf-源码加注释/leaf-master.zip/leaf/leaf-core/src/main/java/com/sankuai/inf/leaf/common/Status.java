package com.sankuai.inf.leaf.common;

public enum  Status {
    SUCCESS,
    EXCEPTION
}
