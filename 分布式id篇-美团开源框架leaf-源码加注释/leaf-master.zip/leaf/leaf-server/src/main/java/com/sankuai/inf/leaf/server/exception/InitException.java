package com.sankuai.inf.leaf.server.exception;

public class InitException extends Exception{
    public InitException(String msg) {
        super(msg);
    }
}
