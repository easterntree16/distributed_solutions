/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.curator.framework.recipes.locks;

import com.google.common.base.Function;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import org.apache.curator.RetryLoop;
import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.WatcherRemoveCuratorFramework;
import org.apache.curator.framework.api.CuratorWatcher;
import org.apache.curator.framework.imps.CuratorFrameworkState;
import org.apache.curator.utils.PathUtils;
import org.apache.curator.utils.ThreadUtils;
import org.apache.curator.utils.ZKPaths;
import org.apache.zookeeper.KeeperException;
import org.apache.zookeeper.WatchedEvent;
import org.apache.zookeeper.Watcher;

public class LockInternals {
    private final WatcherRemoveCuratorFramework client;
    //path就是zk创建锁节点时候的path
    private final String path;
    private final String basePath;
    private final LockInternalsDriver driver;
    private final String lockName;
    private final AtomicReference<RevocationSpec> revocable = new AtomicReference<RevocationSpec>(null);
    private final CuratorWatcher revocableWatcher = new CuratorWatcher() {
        @Override
        public void process(WatchedEvent event) throws Exception {
            if (event.getType() == Watcher.Event.EventType.NodeDataChanged) {
                checkRevocableWatcher(event.getPath());
            }
        }
    };

    private final Watcher watcher = new Watcher() {
        @Override
        public void process(WatchedEvent event) {
            client.postSafeNotify(LockInternals.this);
        }
    };

    //存储最大 租赁的数量
    private volatile int maxLeases;

    static final byte[] REVOKE_MESSAGE = "__REVOKE__".getBytes();

    /**
     * Attempt to delete the lock node so that sequence numbers get reset
     *
     * @throws Exception errors
     */
    public void clean() throws Exception {
        try {
            client.delete().forPath(basePath);
        } catch (KeeperException.BadVersionException ignore) {
            // ignore - another thread/process got the lock
        } catch (KeeperException.NotEmptyException ignore) {
            // ignore - other threads/processes are waiting
        }
    }

    LockInternals(CuratorFramework client, LockInternalsDriver driver, String path, String lockName, int maxLeases) {
        this.driver = driver;
        //lockName 默认是 lock-
        this.lockName = lockName;
        this.maxLeases = maxLeases;

        //zookeeper客户端
        this.client = client.newWatcherRemoveCuratorFramework();
        //加锁创建的zookeeper节点路径
        this.basePath = PathUtils.validatePath(path);
        //构建path,普通锁 会多一个 lock-，写锁或多一个__write__
        this.path = ZKPaths.makePath(path, lockName);
    }

    synchronized void setMaxLeases(int maxLeases) {
        this.maxLeases = maxLeases;
        notifyAll();
    }

    void makeRevocable(RevocationSpec entry) {
        revocable.set(entry);
    }

    final void releaseLock(String lockPath) throws Exception {
        //需要清除所有的监听
        client.removeWatchers();
        revocable.set(null);
        deleteOurPath(lockPath);
    }

    CuratorFramework getClient() {
        return client;
    }

    public static Collection<String> getParticipantNodes(
            CuratorFramework client, final String basePath, String lockName, LockInternalsSorter sorter)
            throws Exception {
        List<String> names = getSortedChildren(client, basePath, lockName, sorter);
        Iterable<String> transformed = Iterables.transform(names, new Function<String, String>() {
            @Override
            public String apply(String name) {
                return ZKPaths.makePath(basePath, name);
            }
        });
        return ImmutableList.copyOf(transformed);
    }

    public static List<String> getSortedChildren(
            CuratorFramework client, String basePath, final String lockName, final LockInternalsSorter sorter)
            throws Exception {
        try {
            //首先通过basePath获取下面的所有子节点
            List<String> children = client.getChildren().forPath(basePath);
            List<String> sortedList = Lists.newArrayList(children);
            Collections.sort(sortedList, new Comparator<String>() {
                @Override
                public int compare(String lhs, String rhs) {
                    return sorter.fixForSorting(lhs, lockName).compareTo(sorter.fixForSorting(rhs, lockName));
                }
            });
            return sortedList;
        } catch (KeeperException.NoNodeException ignore) {
            return Collections.emptyList();
        }
    }

    public static List<String> getSortedChildren(
            final String lockName, final LockInternalsSorter sorter, List<String> children) {
        List<String> sortedList = Lists.newArrayList(children);
        Collections.sort(sortedList, new Comparator<String>() {
            @Override
            public int compare(String lhs, String rhs) {
                return sorter.fixForSorting(lhs, lockName).compareTo(sorter.fixForSorting(rhs, lockName));
            }
        });
        return sortedList;
    }

    List<String> getSortedChildren() throws Exception {
        return getSortedChildren(client, basePath, lockName, driver);
    }

    String getLockName() {
        return lockName;
    }

    LockInternalsDriver getDriver() {
        return driver;
    }

    //开始加锁，lockNodeBytes == null
    String attemptLock(long time, TimeUnit unit, byte[] lockNodeBytes) throws Exception {
        //获取当前时间
        final long startMillis = System.currentTimeMillis();
        //判断time是不是为null。如果不为空，做一次毫秒的转换
        final Long millisToWait = (unit != null) ? unit.toMillis(time) : null;
        //null
        final byte[] localLockNodeBytes = (revocable.get() != null) ? new byte[0] : lockNodeBytes;
        //重入次数，默认是0
        int retryCount = 0;

        //就是创建锁节点成功后的节点全路径
        String ourPath = null;
        boolean hasTheLock = false;
        //如果他是true，就跳出以下循环
        boolean isDone = false;
        while (!isDone) {
            //一进来，先设置为true
            isDone = true;

            try {
                //创建锁
                ourPath = driver.createsTheLock(client, path, localLockNodeBytes);
                //
                hasTheLock = internalLockLoop(startMillis, millisToWait, ourPath);
            } catch (KeeperException.NoNodeException e) {
                // gets thrown by StandardLockInternalsDriver when it can't find the lock node
                // this can happen when the session expires, etc. So, if the retry allows, just try it all again
                if (client.getZookeeperClient()
                        .getRetryPolicy()
                        .allowRetry(
                                retryCount++,
                                System.currentTimeMillis() - startMillis,
                                RetryLoop.getDefaultRetrySleeper())) {
                    isDone = false;
                } else {
                    throw e;
                }
            }
        }

        if (hasTheLock) {
            //如果加锁成功，返回加锁的节点路径
            return ourPath;
        }

        return null;
    }

    private void checkRevocableWatcher(String path) throws Exception {
        RevocationSpec entry = revocable.get();
        if (entry != null) {
            try {
                byte[] bytes = client.getData().usingWatcher(revocableWatcher).forPath(path);
                if (Arrays.equals(bytes, REVOKE_MESSAGE)) {
                    entry.getExecutor().execute(entry.getRunnable());
                }
            } catch (KeeperException.NoNodeException ignore) {
                // ignore
            }
        }
    }

    //内部锁循环判断是否获取锁成功的一个逻辑
    private boolean internalLockLoop(long startMillis, Long millisToWait, String ourPath) throws Exception {
       //是否持有锁，如果后面获取到锁，那么它就是true,如果获取不到锁，那么就一直是false
        boolean haveTheLock = false;
        try {
            if (revocable.get() != null) {
                client.getData().usingWatcher(revocableWatcher).forPath(ourPath);
            }
            //判断当前客户端的一个状态是否STARTED，而且一直没有获取到锁
            while ((client.getState() == CuratorFrameworkState.STARTED) && !haveTheLock) {
                //获取到basePath下所有子节点的一个顺序集合
                List<String> children = getSortedChildren();
                //去掉basePath，留下的就是顺序节点的内容
                String sequenceNodeName = ourPath.substring(basePath.length() + 1); // +1 to include the slash

                //拿到加锁的结果
                PredicateResults predicateResults = driver.getsTheLock(client, children, sequenceNodeName, maxLeases);
                if (predicateResults.getsTheLock()) {
                    //如果获取锁成功，就haveTheLock设置成true,这样就可以跳出加锁的循环
                    haveTheLock = true;
                } else {
                    //我们需要去拼装全路径的待watch的节点
                    String previousSequencePath = basePath + "/" + predicateResults.getPathToWatch();

                    synchronized (this) {
                        try {
                            // use getData() instead of exists() to avoid leaving unneeded watchers which is a type of
                            // resource leak
                            //去添加watch到这个节点
                            client.getData().usingWatcher(watcher).forPath(previousSequencePath);
                            if (millisToWait != null) {
                                //如果millisToWait时间有设置
                                millisToWait -= (System.currentTimeMillis() - startMillis);
                                startMillis = System.currentTimeMillis();
                                if (millisToWait <= 0) {
                                    break;
                                }

                                //等待一定时间
                                wait(millisToWait);
                            } else {
                                //如果没有设置，那么就一直等待。
                                wait();
                            }
                        } catch (KeeperException.NoNodeException e) {
                            // it has been deleted (i.e. lock released). Try to acquire again
                        }
                    }
                }
            }
        } catch (Exception e) {
            ThreadUtils.checkInterrupted(e);
            //删除当前客户端设置的一个节点。为什么要删除。
            //因为我们创建的节点如果不删除，而且当前客户端没有挂掉，那么那个节点就一直存在。阻塞后续客户端的加锁
            deleteOurPathQuietly(ourPath, e);
            throw e;
        }
        if (!haveTheLock) {
            //删除创建的节点
            deleteOurPath(ourPath);
        }
        //返回是否加锁成功
        return haveTheLock;
    }

    private void deleteOurPathQuietly(String ourPath, Exception ex) {
        try {
            deleteOurPath(ourPath);
        } catch (Exception suppressed) {
            ex.addSuppressed(suppressed);
        }
    }

    private void deleteOurPath(String ourPath) throws Exception {
        try {
            client.delete().guaranteed().forPath(ourPath);
        } catch (KeeperException.NoNodeException e) {
            // ignore - already deleted (possibly expired session, etc.)
        }
    }
}
