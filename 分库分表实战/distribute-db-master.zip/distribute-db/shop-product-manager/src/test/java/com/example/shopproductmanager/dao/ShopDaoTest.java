package com.example.shopproductmanager.dao;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class ShopDaoTest {

    @Autowired
    private ShopDao shopDao;

    @Test
    public void testInsert(){
        shopDao.insertShop("好物商店", "中国北京", 1, "13029321923");
    }

    @Test
    public void testSelect(){
        System.out.println(shopDao.queryShopById(922940250588708864L));
    }
}
