package com.example.shopproductmanager.dao;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class ProductDaoTest {

    @Autowired
    private ProductDao productDao;

    @Test
    public void testInsert(){
        productDao.insertProduct(922940250588708864L, "芒果", 100, 20);
    }

    @Test
    public void testInsertDetail(){
        productDao.insertProductDetail(922940250588708864L, 922944967393935360L
                , "芒果描述", "20g");
    }

    @Test
    public void testSelectProduct(){
        System.out.println(productDao.queryProductById(922944967393935360L));
    }

    @Test
    public void testSelectProductByShopId(){
        System.out.println(productDao.queryProductByShopId(922940250588708864L));
    }

    @Test
    public void testSelectProductDetail(){
        System.out.println(productDao.queryProductDetailById(922945699153182720L));
    }

    @Test
    public void testSelectProductAndDetail(){
        System.out.println(productDao.queryProductAndDetail(922944967393935360L));
    }
}
