package com.example.shopproductmanager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShopProductManagerApplicationTests {

    @Test
    void contextLoads() {
    }

}
