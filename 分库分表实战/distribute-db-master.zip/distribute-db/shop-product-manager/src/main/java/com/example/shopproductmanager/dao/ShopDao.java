package com.example.shopproductmanager.dao;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.Map;

@Mapper
public interface ShopDao {

    @Insert("insert into shop (name, address, rating, phone) values" +
            "(#{name}, #{address}, #{rating}, #{phone})")
    void insertShop(@Param("name") String name, @Param("address") String address,
                    @Param("rating") Integer rating, @Param("phone") String phone);


    @Select("select * from shop where id = #{id}")
    Map<String, Object> queryShopById(@Param("id") Long id);
}
