package com.example.distributedb.dao;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

@Mapper
public interface OrderDao {

    @Insert("insert into t_order (user_id, status) values (#{userId}, #{status})")
    void insertOrder(@Param("userId") Integer userId, @Param("status") Integer status);

    @Select("select * from t_order where id = #{id}")
    Map<String, Object> selectOrderById(@Param("id") Long id);

    @Select("select * from t_order where user_id = #{userId}")
    Map<String, Object> selectOrderByUserId(@Param("userId") Integer userId);

    @Select("select * from t_order where  id = #{id} and user_id = #{userId}")
    Map<String, Object> selectOrderByUserIdAndId(@Param("id") Long id, @Param("userId") Integer userId);

    @Select("select a.id, a.user_id, a.status, b.address from t_order a left join t_order_item b " +
            "on a.id = b.order_id where a.id = #{id}")
    List<Map<String, Object>> selectOrderAndItem(@Param("id") Long id);

    @Select("select a.id, a.user_id, a.status, b.value from t_order a left join t_dictionary b " +
            "on a.status = b.code where a.id = #{id}")
    List<Map<String, Object>> selectOrderAndDictionary(@Param("id") Long id);
}
