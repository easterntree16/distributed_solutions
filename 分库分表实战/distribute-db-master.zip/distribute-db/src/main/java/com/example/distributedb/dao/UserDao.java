package com.example.distributedb.dao;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.Map;

@Mapper
public interface UserDao {
    @Insert("insert into t_user_info (phone, name) values (#{phone}, #{name})")
    void insertUser(@Param("phone") String phone, @Param("name") String names);

    @Select("select * from t_user_info where id =#{id}")
    Map<String, Object> selectById(@Param("id") Long id);
}
