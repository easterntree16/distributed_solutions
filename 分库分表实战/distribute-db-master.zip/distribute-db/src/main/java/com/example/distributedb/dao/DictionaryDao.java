package com.example.distributedb.dao;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface DictionaryDao {
    @Insert("insert into t_dictionary (code, value) values (#{code}, #{value})")
    void insertDictionary(@Param("code") String code, @Param("value") String value);
}
