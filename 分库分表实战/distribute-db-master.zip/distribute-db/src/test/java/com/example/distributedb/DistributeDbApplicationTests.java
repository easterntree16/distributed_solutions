package com.example.distributedb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DistributeDbApplicationTests {

    @Test
    void contextLoads() {
    }

}
