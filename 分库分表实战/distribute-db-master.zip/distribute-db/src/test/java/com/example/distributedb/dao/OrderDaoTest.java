package com.example.distributedb.dao;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class OrderDaoTest {

    @Autowired
    private OrderDao orderDao;

    @Test
    public void testInsertOrder() {
        for (int i = 0; i < 10; i++) {
            orderDao.insertOrder(i, 1);
        }
    }

    @Test
    public void testSelectOrder() {
        System.out.println(orderDao.selectOrderById(914891645181231105L));
    }

    @Test
    public void testSelectOrderByUserId() {
        System.out.println(orderDao.selectOrderByUserId(2));
    }

    @Test
    public void testSelectOrderByUserIdAndId() {
        System.out.println(orderDao.selectOrderByUserIdAndId(914900650142203905L, 1));
    }

    @Test
    public void testSelectOrderAndItem() {
        System.out.println(orderDao.selectOrderAndItem(914900650142203905L));
    }

    @Test
    public void testSelectOrderAndDictionary() {
        System.out.println(orderDao.selectOrderAndDictionary(914900650142203905L));
    }
}
