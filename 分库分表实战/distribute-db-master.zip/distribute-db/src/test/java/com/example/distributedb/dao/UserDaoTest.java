package com.example.distributedb.dao;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class UserDaoTest {

    @Autowired
    private UserDao userDao;

    @Test
    public void testInsert() {
        for (int i = 0; i < 4; i++) {
            userDao.insertUser("1320000001" + i, "小红");
        }
    }

    @Test
    public void testSelect(){
        System.out.println(userDao.selectById(922811117984546816L));
    }
}
