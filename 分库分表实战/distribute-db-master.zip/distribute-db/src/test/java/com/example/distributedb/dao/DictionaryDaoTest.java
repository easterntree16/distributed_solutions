package com.example.distributedb.dao;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class DictionaryDaoTest {

    @Autowired
    private DictionaryDao dictionaryDao;

    @Test
    public void testInsert(){
        dictionaryDao.insertDictionary("1", "已发货");
        dictionaryDao.insertDictionary("2", "已送达");
    }
}
