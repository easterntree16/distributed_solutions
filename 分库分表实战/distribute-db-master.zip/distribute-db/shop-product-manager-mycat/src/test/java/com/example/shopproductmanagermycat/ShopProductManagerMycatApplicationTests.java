package com.example.shopproductmanagermycat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShopProductManagerMycatApplicationTests {

    @Test
    void contextLoads() {
    }

}
