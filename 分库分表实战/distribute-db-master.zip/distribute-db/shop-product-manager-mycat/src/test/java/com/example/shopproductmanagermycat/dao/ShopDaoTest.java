package com.example.shopproductmanagermycat.dao;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.ArrayList;
import java.util.List;

@SpringBootTest
public class ShopDaoTest {

    @Autowired
    private ShopDao shopDao;

    @Test
    public void testInsert() {
        shopDao.insertShop(9L, "小吃铺9", "北京", 1, "1432912232");
    }

    @Test
    public void testSelect(){
        List<Long> list = new ArrayList();
        list.add(9L);
        list.add(10L);
        System.out.println(shopDao.selectShopByIds(list));
    }
}
