package com.example.shopproductmanagermycat.dao;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class ProductDaoTest {

    @Autowired
    private ProductDao productDao;

    @Test
    public void testInsertProduct() {
        productDao.insertProduct(1L, 9L, "棉花糖", 10, 10);
    }

    @Test
    public void testInsertProductDetail() {
        productDao.insertProductDetail(1L, 9L, 1L, "这是棉花糖", "10厘米");
    }

    @Test
    public void testQueryProductById() {
        System.out.println(productDao.queryProductById(1L));
    }

    @Test
    public void testQueryProductByShopId() {
        System.out.println(productDao.queryProductByShopId(9L));
    }

    @Test
    public void testQueryProductDetailById() {
        System.out.println(productDao.queryProductDetailById(1L));
    }

    @Test
    public void testQueryProductAndDetail() {
        System.out.println(productDao.queryProductAndDetail(1L));
    }
}
