package com.example.shopproductmanagermycat.dao;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

@Mapper
public interface ProductDao {

    @Insert("insert into product (id, shop_id, name, stock, price) values" +
            "(#{id}, #{shopId}, #{name}, #{stock}, #{price})")
    void insertProduct(@Param("id") Long id, @Param("shopId") Long shopId, @Param("name") String name,
                       @Param("stock") Integer stock, @Param("price") Integer price);

    @Insert("insert into product_detail (id, shop_id, product_id, description, specification) values" +
            "(#{id}, #{shopId}, #{productId}, #{description},#{specification})")
    void insertProductDetail(@Param("id") Long id, @Param("shopId") Long shopId, @Param("productId") Long productId,
                             @Param("description") String description, @Param("specification") String specification);

    @Select("select * from product where id = #{id}")
    Map<String, Object> queryProductById(@Param("id") Long id);

    @Select("select * from product where shop_id = #{shopId}")
    List<Map<String, Object>> queryProductByShopId(@Param("shopId") Long shopId);

    @Select("select * from product_detail where id = #{id}")
    Map<String, Object> queryProductDetailById(@Param("id") Long id);

    @Select("select * from product a, product_detail b where a.id = b.product_id and a.id = #{id}")
    Map<String, Object> queryProductAndDetail(@Param("id") Long id);
}
