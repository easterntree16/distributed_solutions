package com.example.shopproductmanagermycat;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShopProductManagerMycatApplication {

    public static void main(String[] args) {
        SpringApplication.run(ShopProductManagerMycatApplication.class, args);
    }

}
