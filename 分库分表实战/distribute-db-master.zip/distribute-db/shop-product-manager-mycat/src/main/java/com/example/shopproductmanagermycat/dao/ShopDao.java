package com.example.shopproductmanagermycat.dao;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

@Mapper
public interface ShopDao {

    @Insert("insert into shop (id, name, address, rating, phone) values" +
            "(#{id}, #{name}, #{address}, #{rating}, #{phone})")
    void insertShop(@Param("id") Long id, @Param("name") String name, @Param("address") String address,
                    @Param("rating") Integer rating, @Param("phone") String phone);


    @Select("<script>select * from shop where id in " +
            "<foreach collection='ids' item='id' open='(' close=')' separator=','>" +
            "#{id}" +
            "</foreach>" +
            "</script>")
    List<Map<String, Object>> selectShopByIds(@Param("ids") List<Long> ids);
}
