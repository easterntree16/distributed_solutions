package com.xxl.job.test;

import java.util.TreeMap;

public class TreeMapTest {
    public static void main(String[] args) {
        TreeMap<Integer,String> m = new TreeMap<Integer,String>();
        m.put(1,"苹果");
        m.put(3,"香蕉");
        m.put(2,"饼干");
        m.put(4,"橘子");
        m.put(7,"梨");
        m.put(8,"草莓");
        m.put(9,"荔枝");
        System.out.println("元素有："+m);
        System.out.println("tail" + m.tailMap(10));
    }
}
