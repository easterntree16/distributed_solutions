package com.imooc.user_register;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserRegisterApplicationTests {

    @Test
    void contextLoads() {
    }

}
