package com.imooc.user_register;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserRegisterApplication {

    public static void main(String[] args) {
        SpringApplication.run(UserRegisterApplication.class, args);
    }

}
