package com.example.mysqlexpiretask;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MysqlExpireTaskApplicationTests {

    @Test
    void contextLoads() {
    }

}
