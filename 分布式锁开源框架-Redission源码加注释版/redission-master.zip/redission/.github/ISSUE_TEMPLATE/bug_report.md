---
name: Bug report
about: Create a report to help us improve
title: ''
labels: ''
assignees: ''

---

<!--
Try Redisson PRO https://redisson.pro with ultra-fast performance and support by SLA.
-->

**Expected behavior**

**Actual behavior**

**Steps to reproduce or test case**

**Redis version**

**Redisson version**

**Redisson configuration**
