package org.redisson.quarkus.client.it;

import io.quarkus.test.junit.NativeImageTest;

@NativeImageTest
public class NativeQuarkusRedissonClientResourceIT extends QuarkusRedissonClientResourceTest {
}
