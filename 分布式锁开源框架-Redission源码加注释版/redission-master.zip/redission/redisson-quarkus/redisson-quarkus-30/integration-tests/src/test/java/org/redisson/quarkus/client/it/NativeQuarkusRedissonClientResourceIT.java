package org.redisson.quarkus.client.it;

import io.quarkus.test.junit.QuarkusIntegrationTest;

@QuarkusIntegrationTest
public class NativeQuarkusRedissonClientResourceIT extends QuarkusRedissonClientResourceTest {
}
