package com.example.distributetransaction.dao1;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Qualifier;

@Mapper
public interface EmployeeSalaryDao {
    @Insert("insert into employee_salary (employee_id, salary) values (#{employeeId}, #{salary})")
    @Qualifier("sqlSessionFactorySalary")
    void insertEmployeeSalary(@Param("employeeId") Long employeeId, @Param("salary") Integer salary);
}
