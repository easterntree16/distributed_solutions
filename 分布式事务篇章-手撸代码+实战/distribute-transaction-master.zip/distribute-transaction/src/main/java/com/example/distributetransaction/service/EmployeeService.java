package com.example.distributetransaction.service;

import com.example.distributetransaction.dao.EmployeeDao;
import com.example.distributetransaction.dao1.EmployeeSalaryDao;
import com.example.distributetransaction.entity.EmployeeEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class EmployeeService {

    @Autowired
    private EmployeeDao employeeDao;

    @Autowired
    private EmployeeSalaryDao employeeSalaryDao;

    @Transactional(rollbackFor = Exception.class)
    public String join(EmployeeEntity employeeEntity) {
        //第一步，插入员工基础信息
        employeeDao.insertEmployee(employeeEntity);
        //第二步，插入员工薪资
        employeeSalaryDao.insertEmployeeSalary(employeeEntity.getId(), employeeEntity.getSalary());

        int i = 1 / 0;
        return "员工入职成功";
    }
}
