package com.example.distributetransaction;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DistributeTransactionApplication {

    public static void main(String[] args) {
        SpringApplication.run(DistributeTransactionApplication.class, args);
    }

}
