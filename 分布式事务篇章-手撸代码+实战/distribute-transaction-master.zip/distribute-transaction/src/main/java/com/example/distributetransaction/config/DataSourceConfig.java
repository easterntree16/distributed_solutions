//package com.example.distributetransaction.config;
//
//import org.springframework.boot.context.properties.ConfigurationProperties;
//import org.springframework.boot.jdbc.DataSourceBuilder;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//
//import javax.sql.DataSource;
//
//@Configuration
//public class DataSourceConfig {
//
//    @Bean(name = "employeeDataSource")
//    @ConfigurationProperties("spring.employee-datasource")
//    public DataSource employeeDataSource() {
//        return DataSourceBuilder.create().build();
//    }
//
//    @Bean(name = "salaryDataSource")
//    @ConfigurationProperties("spring.salary-datasource")
//    public DataSource salaryDataSource() {
//        return DataSourceBuilder.create().build();
//    }
//}
