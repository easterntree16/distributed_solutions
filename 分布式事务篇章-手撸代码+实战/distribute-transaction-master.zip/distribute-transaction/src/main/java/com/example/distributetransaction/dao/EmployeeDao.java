package com.example.distributetransaction.dao;

import com.example.distributetransaction.entity.EmployeeEntity;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Options;
import org.springframework.beans.factory.annotation.Qualifier;

@Mapper
public interface EmployeeDao {

    @Insert("insert into employee (name, sex, level) values (#{name}, #{sex}, #{level})")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    @Qualifier("sqlSessionFactoryEmployee")
    void insertEmployee(EmployeeEntity employeeEntity);
}
