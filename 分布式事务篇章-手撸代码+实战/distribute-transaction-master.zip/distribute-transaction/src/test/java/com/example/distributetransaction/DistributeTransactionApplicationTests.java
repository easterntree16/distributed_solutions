package com.example.distributetransaction;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DistributeTransactionApplicationTests {

    @Test
    void contextLoads() {
    }

}
