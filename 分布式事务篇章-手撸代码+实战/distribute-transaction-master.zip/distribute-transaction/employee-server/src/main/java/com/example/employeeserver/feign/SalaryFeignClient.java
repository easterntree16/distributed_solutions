package com.example.employeeserver.feign;

import org.dromara.hmily.annotation.Hmily;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient(value = "salary-server", qualifier = "salaryFeignClient")
public interface SalaryFeignClient {

    @PostMapping("/saveSalary")
    @Hmily
    String saveSalary(@RequestParam("employeeId") Long employeeId, @RequestParam("salary") Integer salary);
}
