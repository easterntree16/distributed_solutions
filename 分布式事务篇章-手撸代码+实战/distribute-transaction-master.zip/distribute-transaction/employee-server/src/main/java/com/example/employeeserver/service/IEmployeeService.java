package com.example.employeeserver.service;

import com.example.employeeserver.entity.EmployeeEntity;

public interface IEmployeeService {
    String join(EmployeeEntity employeeEntity);
}
