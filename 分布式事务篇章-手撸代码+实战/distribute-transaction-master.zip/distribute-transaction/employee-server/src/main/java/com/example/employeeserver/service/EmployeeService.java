package com.example.employeeserver.service;

import com.alibaba.fastjson.JSONObject;
import com.example.employeeserver.dao.EmployeeDao;
import com.example.employeeserver.entity.EmployeeEntity;
import com.example.employeeserver.feign.SalaryFeignClient;
import io.seata.spring.annotation.GlobalTransactional;
import org.apache.rocketmq.spring.core.RocketMQTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;

@Service
public class EmployeeService implements IEmployeeService{

    @Autowired
    private EmployeeDao employeeDao;

    @Resource
    @Qualifier("salaryFeignClient")
    private SalaryFeignClient salaryFeignClient;

    @Autowired
    private RocketMQTemplate rocketMQTemplate;

//    @HmilyTCC(confirmMethod = "confirm", cancelMethod = "cancel")
    @GlobalTransactional
    public String join(EmployeeEntity employeeEntity) {
        //第一步，插入员工基础信息
        employeeDao.insertEmployee(employeeEntity);
        //第二步，插入员工薪资
        salaryFeignClient.saveSalary(employeeEntity.getId(), employeeEntity.getSalary());
//        Message<String> message = MessageBuilder.withPayload(JSONObject.toJSONString(employeeEntity)).build();
//        rocketMQTemplate.sendMessageInTransaction("employee-topic", message, null);
        int i = 1 / 0;
        return "员工入职成功";
    }

    public String confirm(EmployeeEntity employeeEntity){
        System.out.println("来confirm");
        //就是去修改员工的状态为已生效
        employeeDao.updateEmployeeStatus(employeeEntity.getId());
        return "confirm";
    }

    public String cancel(EmployeeEntity employeeEntity){
        //直接删除员工数据
        System.out.println("来cancel");
        employeeDao.deleteEmployee(employeeEntity.getId());
        return "cancel";
    }
}
