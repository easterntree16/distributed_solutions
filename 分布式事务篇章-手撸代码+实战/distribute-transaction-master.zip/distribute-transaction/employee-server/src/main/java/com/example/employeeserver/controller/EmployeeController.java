package com.example.employeeserver.controller;

import com.example.employeeserver.entity.EmployeeEntity;
import com.example.employeeserver.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;

    @RequestMapping("/join")
    public String join(@RequestBody EmployeeEntity employeeEntity) {
        try {
            return employeeService.join(employeeEntity);
        } catch (Exception e) {
            e.printStackTrace();
            return "员工入职失败";
        }
    }
}
