package com.example.employeeserver.mq;

import com.alibaba.fastjson.JSONObject;
import com.example.employeeserver.dao.EmployeeDao;
import com.example.employeeserver.entity.EmployeeEntity;
import org.apache.rocketmq.spring.annotation.RocketMQTransactionListener;
import org.apache.rocketmq.spring.core.RocketMQLocalTransactionListener;
import org.apache.rocketmq.spring.core.RocketMQLocalTransactionState;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;

@RocketMQTransactionListener
public class TransactionListener implements RocketMQLocalTransactionListener {

    @Autowired
    private EmployeeDao employeeDao;

    //执行本地事务
    @Override
    public RocketMQLocalTransactionState executeLocalTransaction(Message message, Object o) {
        System.out.println("来执行本地事务了");
        EmployeeEntity employeeEntity = JSONObject.parseObject(new String((byte[]) message.getPayload()), EmployeeEntity.class);
        EmployeeEntity employee = employeeDao.getEmployee(employeeEntity.getId());
        if (employee == null) {
            return RocketMQLocalTransactionState.ROLLBACK;
        }

        employeeDao.updateEmployeeStatus(employeeEntity.getId());
        return RocketMQLocalTransactionState.COMMIT;
    }


    //回查事务状态
    @Override
    public RocketMQLocalTransactionState checkLocalTransaction(Message message) {
        System.out.println("来执行回查逻辑了");
        EmployeeEntity employeeEntity = JSONObject.parseObject(new String((byte[]) message.getPayload()), EmployeeEntity.class);
        EmployeeEntity employee = employeeDao.getEmployee(employeeEntity.getId());
        if (employee == null || employee.getStatus() == null) {
            return RocketMQLocalTransactionState.ROLLBACK;
        }

        return employee.getStatus().equals(1) ? RocketMQLocalTransactionState.COMMIT : RocketMQLocalTransactionState.ROLLBACK;
    }
}
