package com.example.employeeserver.dao;

import com.example.employeeserver.entity.EmployeeEntity;
import org.apache.ibatis.annotations.*;

@Mapper
public interface EmployeeDao {

    @Insert("insert into employee (name, sex, level,status) values (#{name}, #{sex}, #{level},0)")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    void insertEmployee(EmployeeEntity employeeEntity);

    @Update("update employee set status = 1 where id = #{employeeId}")
    void updateEmployeeStatus(@Param("employeeId") Long employeeId);

    @Delete("delete from employee where id = #{employeeId}")
    void deleteEmployee(@Param("employeeId") Long employeeId);

    @Select("select * from employee where id = #{employeeId}")
    EmployeeEntity getEmployee(@Param("employeeId") Long employeeId);
}
