CREATE TABLE `employee`
(
    `id`     bigint       NOT NULL AUTO_INCREMENT,
    `name`   varchar(100) NOT NULL COMMENT '员工名称',
    `sex`    varchar(2)   NOT NULL COMMENT '性别',
    `level`  varchar(10) DEFAULT NULL COMMENT '级别',
    `status` int         DEFAULT NULL COMMENT '状态0未生效，1已生效',
    PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='员工基础信息表'