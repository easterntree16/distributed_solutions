CREATE TABLE `employee_salary`
(
    `id`          bigint NOT NULL AUTO_INCREMENT,
    `employee_id` bigint NOT NULL COMMENT '员工Id',
    `salary`      int    NOT NULL COMMENT '薪资',
    `status`      int DEFAULT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='员工薪资表'