//package com.example.salaryserver.mq;
//
//import com.alibaba.fastjson.JSONObject;
//import com.example.salaryserver.dao.EmployeeSalaryDao;
//import com.example.salaryserver.entity.EmployeeEntity;
//import org.apache.rocketmq.spring.annotation.RocketMQMessageListener;
//import org.apache.rocketmq.spring.core.RocketMQListener;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Component;
//
//@Component
//@RocketMQMessageListener(topic = "employee-topic", consumerGroup = "employee-group")
//public class EmployeeListener implements RocketMQListener<String> {
//
//    @Autowired
//    private EmployeeSalaryDao employeeSalaryDao;
//
//    @Override
//    public void onMessage(String s) {
//        System.out.println("salary监听到消息了" + s);
//        EmployeeEntity employeeEntity = JSONObject.parseObject(s, EmployeeEntity.class);
//        employeeSalaryDao.insertEmployeeSalary(employeeEntity.getId(), employeeEntity.getSalary());
//    }
//}
