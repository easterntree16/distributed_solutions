package com.example.salaryserver.service;

public interface ISalaryService {

    String saveSalary(Long employeeId, Integer salary);
}
