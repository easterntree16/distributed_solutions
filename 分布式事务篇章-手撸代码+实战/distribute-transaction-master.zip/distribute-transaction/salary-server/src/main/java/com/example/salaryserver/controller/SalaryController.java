package com.example.salaryserver.controller;

import com.example.salaryserver.service.SalaryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SalaryController {

    @Autowired
    private SalaryService salaryService;

    @PostMapping("/saveSalary")
    public String saveSalary(Long employeeId, Integer salary) {
        return salaryService.saveSalary(employeeId, salary);
    }
}
