package com.example.salaryserver.dao;

import org.apache.ibatis.annotations.*;
import org.springframework.beans.factory.annotation.Qualifier;

@Mapper
public interface EmployeeSalaryDao {
    @Insert("insert into employee_salary (employee_id, salary, status) values (#{employeeId}, #{salary}, 0)")
    void insertEmployeeSalary(@Param("employeeId") Long employeeId, @Param("salary") Integer salary);

    @Update("update employee_salary set status = 1 where employee_id = #{employeeId}")
    void updateSalaryStatus(@Param("employeeId") Long employeeId);

    @Delete("delete from employee_salary where employee_id = #{employeeId}")
    void deleteByEmployeeId(@Param("employeeId") Long employeeId);
}
