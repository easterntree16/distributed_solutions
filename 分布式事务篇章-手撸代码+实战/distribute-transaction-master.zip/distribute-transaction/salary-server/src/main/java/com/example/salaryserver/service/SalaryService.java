package com.example.salaryserver.service;

import com.example.salaryserver.dao.EmployeeSalaryDao;
import org.dromara.hmily.annotation.HmilyTCC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class SalaryService implements ISalaryService {

    @Autowired
    private EmployeeSalaryDao employeeSalaryDao;

//    @HmilyTCC(confirmMethod = "confirm", cancelMethod = "cancel")
    @Transactional
    public String saveSalary(Long employeeId, Integer salary) {
        employeeSalaryDao.insertEmployeeSalary(employeeId, salary);
        return "保存薪资成功";
    }

    public String confirm(Long employeeId, Integer salary) {
        System.out.println("来confirm");
        employeeSalaryDao.updateSalaryStatus(employeeId);
        return "confirm";
    }

    public String cancel(Long employeeId, Integer salary) {
        System.out.println("来cancel");
        employeeSalaryDao.deleteByEmployeeId(employeeId);
        return "cancel";
    }
}
