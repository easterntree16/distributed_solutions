package com.example.salaryserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SalaryServerApplicationTests {

    @Test
    void contextLoads() {
    }

}
